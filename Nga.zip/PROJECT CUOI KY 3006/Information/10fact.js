function openNav() {
    document.getElementById("mySidepanel").style.width = "230px";
    document.getElementById("mySidepanel").style.height = "650px";

}
function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";

}
